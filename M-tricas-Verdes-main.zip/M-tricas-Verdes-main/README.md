# M-tricas-Verdes
Proyecto para participar en la hackathon de GemaLab, este proyecto consiste en un Dashboard que muestra el estado actual de cada una de las plantas registradas
